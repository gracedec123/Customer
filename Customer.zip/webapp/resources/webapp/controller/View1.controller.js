sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/Fragment",
	"sap/m/MessageToast",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (Controller, Fragment, MessageToast, JSONModel, Filter, FilterOperator) {
	"use strict";

	return Controller.extend("webapp.webapp.controller.View1", {

		onInit: function () {
			this.loadTableData();
			var oDialogModel = new JSONModel({});
			this.getView().setModel(oDialogModel, "dialogModel");
			var oUserModel = new JSONModel({});
			this.getView().setModel(oUserModel, "oUserModel");
			var that = this;
			$.ajax({
				url: "/xsjs_crud/FetchUsernameDetails.xsjs",
				method: "GET",
				contentType: "application/json",
				success: function (oData) {
					that.getView().getModel("oUserModel").setProperty("/userName", oData.Database_Application_User);
				},
				error: function () {
					MessageToast.show("An error occurred while adding the record. Please try again later.");
				}
			});

		},

		onAdd: function () {
			if (!this._oDialog) {
				Fragment.load({
					id: this.getView().getId(),
					name: "webapp.webapp.fragment.AddItemDialog",
					controller: this
				}).then(function (oDialog) {
					this._oDialog = oDialog;
					this.getView().addDependent(this._oDialog);
					this.getView().getModel("dialogModel").setData({});

					this._oDialog.setModel(this.getView().getModel("dialogModel"));

					this._oDialog.open();
					this._oDialog.attachAfterClose(function () {
						this._oDialog.destroy();
						this._oDialog = null;
					}.bind(this));
				}.bind(this));
			} else {
				this._oDialog.open();
			}
		},

		onSave: function () {
			// var oTableModel = this.getView().getModel("tableModel");
			var oDialogModel = this.getView().getModel("dialogModel");
			var oNewItem = oDialogModel.getData();

			if (!oNewItem.TITLE || !oNewItem.REGION || !oNewItem.VALID_FROM || !oNewItem.VALID_TO) {
				MessageToast.show("Please fill in all mandatory fields!");
				return;
			}
			oNewItem.LAST_MODIFIED_USER = this.getView().getModel("oUserModel").getProperty("/userName");
			oNewItem.LAST_MODIFIED_TIMESTAMP = this.formatDateobjToBackendDateString(new Date());
			for (var key in oNewItem) {
				if (oNewItem[key] !== null && typeof oNewItem[key] === "number") {
					oNewItem[key] = oNewItem[key].toString();
				} else if (oNewItem[key] === null) {
					oNewItem[key] = "";
				}
			}
			$.ajax({
				url: "/xsjs_crud/CUDCountryRegion.xsjs?cmd=insertupdate",
				method: "POST",
				contentType: "application/json",
				data: JSON.stringify(oNewItem),
				success: function () {
					this.loadTableData();
					oDialogModel.setData({});
					this._oDialog.close();
					MessageToast.show("Record Added Successfully!");
				}.bind(this),
				error: function () {
					MessageToast.show("An error occurred while adding the record. Please try again later.");
				}
			});
		},
		loadTableData: function () {

			var oTableModel = new JSONModel();
			this.getView().setModel(oTableModel, "tableModel");
			$.ajax({
				url: "/xsjs_crud/FetchCountryRegionDetails.xsjs",
				method: "GET",
				success: function (data) {
					data = data.map(function (item) {
						item.VALID_FROM = new Date(item.VALID_FROM).toISOString().split('T')[0];
						item.VALID_TO = new Date(item.VALID_TO).toISOString().split('T')[0];
						return item;
					});
					oTableModel.setData(data);
				},
				error: function () {
					MessageToast.show("An error occurred while loading the records. Please try again later.");
				}
			});
		},

		onCancel: function () {
			this.getView().getModel("dialogModel").setData({});
			this._oDialog.close();
		},
		// onView: function (oEvent) {
		// 	var oSelectedItem = oEvent.getSource().getParent().getBindingContext("tableModel");
		// 	var oSelectedData = oSelectedItem.getObject();

		// 	this.getView().getModel("dialogModel").setData(oSelectedData);

		// 	if (!this._oDialog) {
		// 		Fragment.load({
		// 			id: this.getView().getId(),
		// 			name: "webapp.webapp.fragment.ViewItemDialog",
		// 			controller: this
		// 		}).then(function (oDialog) {
		// 			this._oDialog = oDialog;
		// 			this.getView().addDependent(this._oDialog);

		// 			if (!this._oDialog.getModel()) {
		// 				this._oDialog.setModel(this.getView().getModel("dialogModel"));
		// 			}

		// 			this._oDialog.open();

		// 			this._oDialog.attachAfterClose(function () {
		// 				this._oDialog.destroy();
		// 				this._oDialog = null;
		// 			}.bind(this));
		// 		}.bind(this));
		// 	} else {

		// 		this._oDialog.setModel(this.getView().getModel("dialogModel"));
		// 		this._oDialog.open();
		// 	}
		// },
		onEdit: function (oEvent) {
			var oSelectedItem = oEvent.getSource().getParent().getBindingContext("tableModel");
			var oSelectedData = oSelectedItem.getObject();
			this.oOriginalItem = Object.assign({}, oSelectedData);
			this.getView().getModel("dialogModel").setData(this.oOriginalItem);

			if (!this._oDialog) {
				Fragment.load({
					id: this.getView().getId(),
					name: "webapp.webapp.fragment.UpdateItemDialog",
					controller: this
				}).then(function (oDialog) {
					this._oDialog = oDialog;
					this.getView().addDependent(this._oDialog);

					if (!this._oDialog.getModel()) {
						this._oDialog.setModel(this.getView().getModel("dialogModel"));
					}

					this._oDialog.open();
					this._oDialog.attachAfterClose(function () {
						this._oDialog.destroy();
						this._oDialog = null;
					}.bind(this));
				}.bind(this));
			} else {
				this._oDialog.open();
			}
		},
		onUpdate: function () {
			var oTableModel = this.getView().getModel("tableModel");
			var oDialogModel = this.getView().getModel("dialogModel");
			var oUpdatedItem = oDialogModel.getData();
			if (!oUpdatedItem.TITLE || !oUpdatedItem.REGION || !oUpdatedItem.VALID_FROM || !oUpdatedItem.VALID_TO) {
				MessageToast.show("Please fill in all mandatory fields!");
				return;
			}
			oUpdatedItem.LAST_MODIFIED_USER = this.getView().getModel("oUserModel").getProperty("/userName");
			oUpdatedItem.LAST_MODIFIED_TIMESTAMP = this.formatDateobjToBackendDateString(new Date());
			for (var key in oUpdatedItem) {
				if (typeof oUpdatedItem[key] === "number") {
					oUpdatedItem[key] = oUpdatedItem[key].toString();
				} else if (oUpdatedItem[key] === null) {
					oUpdatedItem[key] = "";
				}
			}
			var aTableData = oTableModel.getData();
			$.ajax({
				url: "/xsjs_crud/CUDCountryRegion.xsjs?cmd=insertupdate",
				method: "PUT",
				contentType: "application/json",
				data: JSON.stringify(oUpdatedItem),
				success: function () {
					var nIndex = aTableData.findIndex(function (item) {
						return item.TITLE === oUpdatedItem.TITLE;
					});

					if (nIndex !== -1) {
						aTableData.splice(nIndex, 1, Object.assign({}, oUpdatedItem));
						oTableModel.setData(aTableData);
						oDialogModel.setData({});
						this._oDialog.close();
						MessageToast.show("Record Updated Successfully!");
					} else {
						MessageToast.show("Record not found for update.");
					}
				}.bind(this),
				error: function () {
					MessageToast.show("An error occurred while updating the record. Please try again later.");
				}
			});
		},

		onCancelUpdate: function () {
			this.getView().getModel("dialogModel").setData(this.oOriginalItem);
			this._oDialog.close();
		},
		onSearch: function (event) {
			var searchTerm = event.getParameter("query");
			var table = this.byId("tableId1");
			var binding = table.getBinding("items");

			if (searchTerm === "") {
				binding.filter([]);
			} else {
				var oFilterArr = new Filter([
					new Filter("TITLE", FilterOperator.Contains, searchTerm),
					new Filter("REGION", FilterOperator.Contains, searchTerm),
					new Filter("VALID_FROM", FilterOperator.Contains, searchTerm),
					new Filter("VALID_TO", FilterOperator.Contains, searchTerm)
				], false);
				binding.filter([oFilterArr]);
			}
		},

		onDelete: function (oEvent) {
			// var oTable = this.byId("tableId1");
			var oSelectedItem = oEvent.getSource().getParent();
			var oContext = oSelectedItem.getBindingContext("tableModel");
			sap.m.MessageBox.confirm("Are you sure you want to delete this record?", {
				title: "Confirmation",
				onClose: function (oAction) {
					if (oAction === sap.m.MessageBox.Action.OK) {
						var oTableModel = this.getView().getModel("tableModel");
						var aTableData = oTableModel.getData();
						var nIndex = aTableData.findIndex(function (item) {
							return JSON.stringify(item) === JSON.stringify(oContext.getProperty());
						});
						if (nIndex !== -1) {

							$.ajax({
								url: "/xsjs_crud/CUDCountryRegion.xsjs?cmd=delete", 
								method: "DELETE",
								contentType: "application/json",
								data: JSON.stringify(oContext.getProperty()),
								success: function () {

									aTableData.splice(nIndex, 1);
									oTableModel.refresh(true);
									MessageToast.show("Record Deleted Successfully!");
								},
								error: function () {
									MessageToast.show("An error occurred while deleting the record. Please try again later.");
								}
							});
						}
					}
				}.bind(this)
			});
		},

		formatDateobjToBackendDateString: function (oDate) {

			if (!oDate) {

				return "";

			}

			oDate = new Date(oDate);

			var dd = oDate.getDate();

			var MM = oDate.getMonth() + 1;

			var yy = oDate.getFullYear();

			if (dd < 10) {

				dd = "0" + dd;

			}

			if (MM < 10) {

				MM = "0" + MM;

			}

			var newDate = yy + "-" + MM + "-" + dd;

			var hh = oDate.getHours();

			if (hh < 10) {

				hh = "0" + hh;

			}

			hh = hh.toString();

			var mi = oDate.getMinutes();

			if (mi < 10) {

				mi = "0" + mi;

			}

			mi = mi.toString();
			var ss = oDate.getSeconds();
			if (ss < 10) {
				ss = "0" + ss;
			}
			ss = ss.toString();
			var ms = oDate.getMilliseconds();
			if (ms < 100) {
				ms = "0" + ms;
			}
			var time = hh + ":" + mi + ":" + ss + "." + ms;
			newDate = newDate + "T" + time + "Z";
			return newDate;
		}
	});
});